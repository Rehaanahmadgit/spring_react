import React from 'react'
import BookList from './BookList'

export default function App() {
  return (
    <div>
      <BookList/>
    </div>
  )
}
