import axios from 'axios';

export const getallbook=()=>axios.get('http://localhost:8080/api/books');
export const getbyid=(id)=>axios.get(`http://localhost:8080/api/books/${id}`);  
export const addbook=(book)=>axios.post('http://localhost:8080/api/books',book);
export const updatebook=(id,book)=>axios.put(`http://localhost:8080/api/books/${id}`,book);
export const deletebook=(id)=>axios.delete(`http://localhost:8080/api/books/${id}`);

