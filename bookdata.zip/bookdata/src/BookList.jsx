import React, { useState, useEffect } from 'react';
import { getallbook, updatebook, addbook, deletebook } from './services/bookService';

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [editingBook, setEditingBook] = useState(null);

  const loadBooks = async () => {
    setBooks((await getallbook()).data);
  };

  useEffect(() => {
    loadBooks();
  }, []);

 

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (editingBook) {
      await updatebook(editingBook.id,{ name, phone });
      setEditingBook(null);
    } else {
      await addbook({ name, phone });
    }
    setName('');
    setPhone('');
    loadBooks();
  };

  const handleEdit = (bookdata) => {
    setName(bookdata.name);
    setPhone(bookdata.phone);
    setEditingBook(bookdata);
  };

  const handleDelete = async (id) => {
    await deletebook(id);
    loadBooks();
  };

  return (
    <div>
      <h2>Library Management System</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
        <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Phone" />
        <button type="submit">{editingBook ? "Update" : "Add"} Save</button>
      </form>
      <ul>
        {books.map((bookdata) => (
          <li key={bookdata.id}>
            {bookdata.name} {bookdata.phone}
            <button onClick={() => handleEdit(bookdata)}>Edit</button>
            <button onClick={() => handleDelete(bookdata.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

